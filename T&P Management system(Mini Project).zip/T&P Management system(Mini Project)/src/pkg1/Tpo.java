package pkg1;

public interface Tpo {
      void  Criteria();
      void CheckEligibility(int marks);
}
