package pkg1;

import java.util.Scanner;

public class Company implements Tpo {
    Scanner sc = new Scanner(System.in);
    private int LNT, tech, tcs, bitwise, persis;

    public Company() {

    }

    public void Criteria() {
        System.out.println("Eligibility criteria for LNT");
        int LNT = sc.nextInt();
        System.out.println(LNT + " Percentage");
        System.out.println("Eligibility criteria for Tech Mahindra");
        int tech = sc.nextInt();
        System.out.println(tech + " Percentage");
        System.out.println("Eligibility criteria for TCS");
        int tcs = sc.nextInt();
        System.out.println(tcs + " Percentage");
        System.out.println("Eligibility criteria for Bitwise");
        int bitwise = sc.nextInt();
        System.out.println(bitwise + " Percentage");
        System.out.println("Eligibility criteria for Persistent");
        int persis = sc.nextInt();
        System.out.println(persis + " Percentage");

        this.LNT = LNT;
        this.tech = tech;
        this.tcs = tcs;
        this.bitwise = bitwise;
        this.persis = persis;

    }

    public void CheckEligibility(int marks) {

        if (marks >= 55) {

            if (marks >= persis) {
                System.out.println("Eligible for Persistent Campus");
            }
            if (marks >= bitwise) {

                System.out.println("Eligible for Bitwise Campus");
            }
            if (marks >= tcs) {

                System.out.println("Eligible for TCS Campus");
            }
            if (marks >= tech) {

                System.out.println("Eligible for Tech Mahindra Campus");
            }

            if (marks >= LNT) {

                System.out.println("Eligible for LNT Campus");
            }
        } else {

            System.out.println("Not Eligible for Campus Placements");
        }
    }
}










