package pkg1;

import java.util.Scanner;

public class MainClass {
    private static int i;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Student s1[] = new Student[100];
        Student s = new Student();
        Company c = new Company();
        String z;

        do {
            System.out.println("1.Fill Company Criteria.");
            System.out.println("2.Enter Student Data");
            System.out.println("3.Display Student Data.");
            System.out.println("4.Placed Student list.");

            System.out.println("Enter Your Choice");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:

                    c.Criteria();

                    break;

                case 2:

                    System.out.println("Enter Roll_no : ");
                    int roll_no = sc.nextInt();
                    System.out.println("Enter Name : ");
                    String name = sc.next();
                    System.out.println("Enter Marks : ");
                    int marks = sc.nextInt();
                    s1[i] = new Student(roll_no, name, marks);
                    i++;

                    break;

                case 3:
                    for (Student ss : s1) {
                        if (ss != null) {
                            ss.OutputData();
                        }

                    }

                    break;

                case 4:
                    for (Student ss : s1) {
                        if (ss != null) {
                            System.out.println(ss.name);
                            c.CheckEligibility(ss.marks);

                        }
                    }

                    break;
            }
            System.out.println("Do you want to continue: (y/n):");
            z = sc.next();
        }

        while (z.equals("y"));

    }
}
